/* $Id$ */
# include "cppad/error_handler.hpp"
